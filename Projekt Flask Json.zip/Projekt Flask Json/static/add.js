function sendPost(){
    console.log("fut");
    const data = JSON.stringify({
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        address: document.getElementById("address").value,
        age: document.getElementById("age").value
      });
      console.log("fut");
      navigator.sendBeacon('http://127.0.0.1:5000/savedetails/', data);
      console.log(data);
      console.log("redirect ment");
    }